import React, { useContext, useState } from "react";
import TypeArea from "./TypeArea";
import StatsArea from "./StatsArea";
import AbilityArea from "./AbilityArea";
import PokemonContext from "./PokemonContext";
function changeCase(name) {
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function PokeCard(props) {
  const pokemon = useContext(PokemonContext);
  return (
    <div
      className={"card" + (props.flip === props.id ? "flipped" : "")}
      onClick={() => props.handleClick(props.id)}
    >
      <div className="front">
        <img src={pokemon.sprites.front_default} />
        <p>{changeCase(pokemon.name)}</p>
        <TypeArea />
      </div>
      <div className="back">
        <h1>{changeCase(pokemon.name)}</h1>
        <AbilityArea abilities={pokemon.abilities} />
        <StatsArea stats={pokemon.stats} flip={props.flip === props.id} />
      </div>
    </div>
  );
}

export default PokeCard;
