import React, { createContext } from "react";

export default PokemonContext = createContext(null);
