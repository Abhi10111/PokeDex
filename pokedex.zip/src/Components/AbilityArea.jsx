import React from "react";

function changeCase(name) {
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function createAbility(ability) {
  return <p className={ability}>{changeCase(ability)}</p>;
}

export default function AbilityArea(props) {
  return (
    <div className="abilityArea">
      {props.abilities.map((ability) => createAbility(ability.ability.name))}
    </div>
  );
}
