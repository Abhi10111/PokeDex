import React from "react";

function changeCase(name) {
  if (name === "special-attack") {
    return "Sp-Atk";
  }
  if (name === "special-defense") {
    return "Sp-Def";
  }
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function statBar(stat, flip) {
  return (
    <div className="stat">
      <div className="name">
        <p>{changeCase(stat.stat.name)}</p>
      </div>
      <div className="value">
        <p>{stat.base_stat}</p>
      </div>
      <div className="bar">
        <div className={"backbar"}></div>
        <div
          className="frontbar"
          style={
            flip
              ? { width: Math.min((stat.base_stat / 100) * 100, 100) }
              : { width: 0 }
          }
        ></div>
      </div>
    </div>
  );
}

export default function StatsArea(props) {
  return (
    <div className="statsArea">
      {props.stats.map((stat) => statBar(stat, props.flip))}
    </div>
  );
}
