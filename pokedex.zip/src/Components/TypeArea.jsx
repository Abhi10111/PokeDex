import React, { useContext, useState } from "react";
import PokemonContext from "./PokemonContext";
function changeCase(name) {
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function createType(type) {
  return <p className={type}>{changeCase(type)}</p>;
}
export default function TypeArea() {
  const pokemon = useContext(PokemonContext);
  return (
    <div className="typeArea">
      {pokemon.types.map((type) => createType(type.type.name))}
    </div>
  );
}
