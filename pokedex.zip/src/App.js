import React, { useEffect, useState } from "react";
import "./styles.css";
import PokeCard from "./Components/PokeCard";
import PokemonContext from "./Components/PokemonContext";

let host = "https://pokeapi.co/api/v2/pokemon/";

export default function App() {
  const [pokeDex, setPokeDex] = useState([]);
  const [flip, setFlip] = useState([0]);
  useEffect(() => {
    for (i = 1; i <= 60; i++) {
      fetch(host + i)
        .then((response) => response.json())
        .then((data) => updatePokedex(data));
    }
  }, []);
  function updatePokedex(pokemon) {
    setPokeDex((prevValue) => {
      return [...prevValue, pokemon];
    });
  }
  function handleClick(id) {
    setFlip(id === flip ? 0 : id);
  }
  return (
    <div className="container">
      {pokeDex.map((pokemon, index) => (
        <PokemonContext.Provider value={pokemon}>
          <PokeCard
            key={index + 1}
            id={index + 1}
            flip={flip}
            handleClick={handleClick}
          />
        </PokemonContext.Provider>
      ))}
    </div>
  );
}
